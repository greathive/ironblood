* **מוד:** משמש עבור המוד שלך בלבד. (קרא לפונקציה כמו `${modid}:${registryname}`)

* **Minecraft:** נמצא בשימוש עם כמה אפשרויות של Minecraft (קרא לפונקציה כמו `minecraft:${registryname}`)