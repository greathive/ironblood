זהו סוג כללי המשחק. עליך לבחור את הסוג הטוב ביותר בהתאם לתוכניות שלך(s)
* Number means the game rule can only be modified to be a number (integer)
* היגיון אומר שכלל המשחק יכול להיות רק בוליאני (נכון או שקר)