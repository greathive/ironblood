מצב זה קובע אם ההסרה הושלמה. אם המצב נכשל, המתקן יפעיל את אפקט הכשל.

הערך של הליך זה מועבר אל "${l10n.t("elementgui.item_extension.dispense_result_itemstack")}" בתור תלות ה"הצלחה".