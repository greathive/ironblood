קטגוריית כריכת מפתח היא קטגוריה המוצגת בחלק הפקדים של הגדרות Minecraft.

כל חיבורי המפתחות השייכים לאותה קטגוריה צריכים להיות בעלי אותו מפתח קטגוריה.

כדי להגדיר את שם הקטגוריה בפועל, עבור אל **${l10n.t("tab.workspace")} -> ${l10n.t("workspace.category.localization")} -> ${l10n.t("workspace.localization.add_entry")}** והשתמש ב-`key.category.${data.keyBindingCategoryKey}` עבור שם הערך ולאחר מכן הגדר את הערך לשם הקטגוריה הרצויה.