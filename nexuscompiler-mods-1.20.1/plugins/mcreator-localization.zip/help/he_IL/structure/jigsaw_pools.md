רשום כאן חלקים ממבנה ה-jigsaw שלך. השתמש בבריכות כדי לקבץ חלקים המיועדים להצבה בעמדות דומות.

Make sure the jigsaws in your pieces have the target repository name as `${modid}:${registryname}_<pool_name>` if they need to place puzzle pieces listed below.
