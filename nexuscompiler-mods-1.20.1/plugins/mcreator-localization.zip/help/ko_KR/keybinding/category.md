키 바인딩 카테고리는 마인크래프트 설정의 컨트롤 섹션에 표시된 카테고리입니다.

같은 카테고리에 속하는 모든 키 바인딩은 같은 카테고리 키를 가져야 합니다.

실제로 카테고리 이름을 설정하려면 **${l10n.t("tab.workspace")}로 이동하세요. -> ${l10n.t("workspace.category.localization")}로 이동하세요. -> ${l10n.t("workspace.localization.add_entry")}**로 이동하고 항목 이름에 `key.category.${data.keyBindingCategoryKey}`를 사용합니다. 를 찾은 다음 원하는 카테고리 이름으로 값을 설정합니다.