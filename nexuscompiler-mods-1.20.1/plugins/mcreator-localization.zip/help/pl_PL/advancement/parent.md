To jest postęp, po którym następuje twoje osiągnięcie.

Możesz użyć "No parent: root", żeby utworzyć nową ścieżkę (nową zakładkę postępów).