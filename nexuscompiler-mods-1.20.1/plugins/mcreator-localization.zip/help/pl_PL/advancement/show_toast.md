Pokaż osiągnięcie w górnym rogu ekranu po prawej, gdy gracz ukończy osiągnięcie.
