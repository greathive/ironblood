To jest rodzaj osiągnięcia

* Zadanie jest podstawowym typem osiągnięcia i jest najpowszechniejsze.
* Cel jest celem długoterminowym, który staramy się osiągnąć.
* Wyzwanie polega na przetestowaniu gracza lub rzuceniu mu jakiegoś wyzwania.