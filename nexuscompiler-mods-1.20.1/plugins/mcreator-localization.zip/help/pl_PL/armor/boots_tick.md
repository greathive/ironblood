Gdy byt ma założone buty, procedura będzie wykonywana na każdym tick-u.

Przekazany byt to byt noszący zbroję, a przekazany stos przedmiotów to stos przedmiotów reprezentujący zbroję.