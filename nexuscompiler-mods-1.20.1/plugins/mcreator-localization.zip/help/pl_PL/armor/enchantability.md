Jak często rzadkie zaklęcia mogą być użyte na tej zbroi. Im wyższa podatność na zaklęcia, tym lepsze zaklęcia otrzymasz podczas zaklinania pancerza.

Wartości Vanilla:

* Skórzana zbroja: 15
* Kolczasta zbroja: 12
* Żelazna zbroja: 9
* Złota zbroja: 25
* Diamentowa zbroja: 10
* Netherytowa zbroja: 15