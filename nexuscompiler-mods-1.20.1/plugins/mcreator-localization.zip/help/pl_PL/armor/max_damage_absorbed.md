Ten parametr definiuje trwałość pancerza i jest skutecznie stosowany jako:

* hełm: max_obrażenia_absorbowane * 11
* klatka piersiowa: max_obrażenia_absorbowane * 16
* nogawice: max_obrażenia_absorbowane * 15
* buty: max_obrażenia_absorbowane * 13

Zbroja vanilii używa następujących czynników:

* Skórzana zbroja: 5
* Kolczasta zbroja: 15
* Żelazna zbroja: 15
* Złota zbroja: 7
* Diamentowa zbroja: 33
* Netherytowa zbroja: 37