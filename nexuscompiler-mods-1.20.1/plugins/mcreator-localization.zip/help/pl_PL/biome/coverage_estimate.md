To pole dostarcza oszacowanie, ile procent powierzchni Overworlda będzie pokryta przez ten biom. Działa tylko poprawnie, jeżeli wartości dla biomu są między -1, a 1, ponieważ ten zasięg używają biomy z Overworlda.

W przypadku, jeżeli twój biom występuje w Piekle lub w jaskiniach Overworlda, to oszacowanie jest nieprawidłowe.

Jeżeli biom występuje w niestandardowych wymiarach, wtedy pokrycie zależy od tego, ile biomów ten wymiar posiada oraz parametrów generacji biomów tego wymiaru.