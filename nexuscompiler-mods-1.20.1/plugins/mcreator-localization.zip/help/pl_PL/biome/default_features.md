Domyślne funkcje to wstępnie skonfigurowane funkcje (funkcje Minecraft), które mogą być użyte w twoim biomie.
