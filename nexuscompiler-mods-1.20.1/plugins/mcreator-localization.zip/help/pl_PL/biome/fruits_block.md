Ten parametr kontroluje blok użyty dla owoców, na przykład ziarna kakaowe na dżunglowych drzewach, o ile są włączone niestandardowe drzewa.

Wybierz blok powietrza, aby wyłączyć owoce na drzewach.