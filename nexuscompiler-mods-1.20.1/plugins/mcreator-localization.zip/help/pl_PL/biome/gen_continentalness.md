Kontynentalność kontroluje, jak daleko od brzegu występuje biom. Mniejsze wartości oznaczają, że biom będzie występował bliżej brzegu, a wyższe wartości oznaczają, że biom będzie dalej od brzegu oraz na wyższej wysokości (przykład: góry).

Biomy z podobną kontynentalnością będą generowane bliżej siebie i będą konkurować o to samo miejsce w trakcie generacji świata. Zbyt podobne wartości skutkują niewygenerowaniem któregoś z biomów.

Kiedy wartość od -2 do 2 są niepoprawne, biomy vanilli używają tylko wartości w zasięgu od -1 do 1.

Biomy vanilli w Overwordzie używają tych zakresów wartości:

* Głęboki ocean: -1,05 do -0,455
* Ocean: -0,455 do -0,19
* Wybrzeże: -0,19 do -0,11
* Lądowy: -0,11 do 0,55
* Nisko lądowy: -0,11 do 0,03
* Średnio lądowy: 0,03 do 0,3
* Wysoko lądowy: 0,3 do 1,0