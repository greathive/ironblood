Erozja kontroluje, jak bardzo zniszczony jest teren. Mniejsze wartości opisują biomy, które zazwyczaj generowane są w bardziej płaskich regionach świata.

Biomy z podobną erozją będą generowane bliżej siebie i będą konkurować o to samo miejsce w trakcie generacji świata. Zbyt podobne wartości skutkują niewygenerowaniem któregoś z biomów.

Kiedy wartość od -2 do 2 są niepoprawne, biomy vanilli używają tylko wartości w zasięgu od -1 do 1.

Różne biomy vanilli w Overwordzie używają tych zakresów wartości:

* -1,0 do -0,78
* -0,78 do -0,375
* -0,375 do -0,2225
* -0,2225 do 0,05
* 0,05 do 0,45
* 0,45 do 0,5
* 0,55 do 1,0