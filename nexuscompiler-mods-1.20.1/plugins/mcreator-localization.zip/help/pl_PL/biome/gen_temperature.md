Ten parametr kontroluje generację biomu, ale nie klimatu.

Biomy z podobną temperaturą będą generowane bliżej siebie i będą konkurować o to samo miejsce w trakcie generacji świata. Zbyt podobne wartości skutkują niewygenerowaniem któregoś z biomów.

Kiedy wartość od -2 do 2 są niepoprawne, biomy vanilli używają tylko wartości w zasięgu od -1 do 1.

Różne biomy vanilli w Overwordzie używają tych zakresów wartości:

* -1,0 do -0,45
* -0,45 do -0,15
* -0,15 do 0,2
* 0,2 do 0,55
* 0,5 do 1,0