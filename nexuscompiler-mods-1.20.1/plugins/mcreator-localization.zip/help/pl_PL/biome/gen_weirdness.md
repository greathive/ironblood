Biomy z podobną dziwnością będą generowane bliżej siebie i będą konkurować o to samo miejsce w trakcie generacji świata. Zbyt podobne wartości skutkują niewygenerowaniem któregoś z biomów.

Kiedy wartość od -2 do 2 są niepoprawne, biomy vanilli używają tylko wartości w zasięgu od -1 do 1.