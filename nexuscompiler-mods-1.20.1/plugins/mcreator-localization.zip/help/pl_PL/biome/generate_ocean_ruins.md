Wybierz to ustawienie, aby generować oceaniczne ruiny w swoim biomie.
* BRAK: Oceaniczne ruiny nie będą generowane.
* ZIMNE: Oceaniczne ruiny zrobione z kamienia będą generowane
* CIEPŁE: Oceaniczne ruiny z piaskowca będą generowane