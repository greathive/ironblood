Ten parametr kontroluje kolor trawy w tym biomie.

Ten parametr również zmienia kolor innych roślin (liści).