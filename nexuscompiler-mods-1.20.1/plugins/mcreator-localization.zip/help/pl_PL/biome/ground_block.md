Ten parametr kontroluje jaki blok będzie generowany na powierzchni w tym biomie.

Ogólnie, vanilliowym lub niestandardowym biomie trawa jest najczęściej wybierana.

Ten blok powinien mieć materiał GRASS i być otagowany w <b>minecraft:dirt</b> Tagi bloków dla modów Forge dla roślin i drzew do prawidłowego pojawiania się w biomie.