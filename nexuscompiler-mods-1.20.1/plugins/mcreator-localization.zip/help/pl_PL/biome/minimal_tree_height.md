Ten parametr kontroluje minimalną wysokość pnia drzewa w tym biomie.

Stosowane, tylko jeśli wybrano niestandardowe drzewa w tym biomie.