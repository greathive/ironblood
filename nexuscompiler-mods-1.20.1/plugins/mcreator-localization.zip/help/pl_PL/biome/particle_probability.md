Prawdopodobieństwo pojawienia się cząsteczek.

UWAGA: Ta wartość jest dzielona przez 100 w kodzie.