Wybierz żywe obiekty, które mogą pojawić się naturalnie w twoim biomie.

Wybierz tylko pasywne lub agresywny moby. Nie wybieraj gracza lub specjalnych mobów, ponieważ to może spowodować awarię świata podczas próby przywołania takich obiektów.