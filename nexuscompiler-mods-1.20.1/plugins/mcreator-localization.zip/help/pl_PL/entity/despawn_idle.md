Jeśli zaznaczone, ten mob się zdespawnuje, gdy gracz odsunie się wystarczająco daleko (domyślne zachowanie dla większości mobów).

Wyłącz to dla bossów i wzywalnych mobów, aby przestały się despawnować.