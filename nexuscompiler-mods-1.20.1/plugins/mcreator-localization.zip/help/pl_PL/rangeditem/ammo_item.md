Ten parametr odpowiada za amunicję używaną przez przedmiot dystansowy.

Przykład: strzała dla łuku.