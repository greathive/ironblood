Ikona służąca identyfikacji zakładki menu trybu kreatywnego, taka jak czerwony proszek w przypadku zakładki z redstonem.

Tylko przedmioty są tutaj obsługiwane. Bloki nieposiadające przedmiotu nie mogą być ukazane jako ikona.