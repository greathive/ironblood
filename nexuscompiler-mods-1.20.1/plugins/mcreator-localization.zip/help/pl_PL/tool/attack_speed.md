Ten parametr kontroluje jak szybko można używać twoje narzędzie.

Ten atrybut kontroluje długość czasu odnowienia, kiedy czas będzie wynosił T = 1 / prędkość ataku * 20 tików.

Mnożnik obrażeń wynosi 0,2 + ((t + 0,5) / T) ^ 2 * 0,8, ograniczony w zasięgu od 0,2 do 1, gdzie t jest numerem tików od ostatniego ataku lub zamiany przedmiotu.